AiGame4 Sprite Pack 1 — iteration 2
Base main commit: 08450bcbfbb9ddf430251d4f2ed9314d65ed42f6

Files:
- game/resources/sprites/characters/player/player_idle.png — 4 frames, 64x64
- game/resources/sprites/characters/player/player_walk.png — 6 frames, 64x64

Source: generated sprite presentation sheet, then extracted/normalized into
runtime sprite sheets with transparent background and 64x64 NEAREST resizing.

QA:
- idle sheet: (256, 64), RGBA, 4 frames
- walk sheet: (384, 64), RGBA, 6 frames

Note:
This is an art iteration for review, not a main-branch commit.
The GitHub connector was tested for write access; branch creation returned HTTP 403
(Resource not accessible by integration), so these assets are provided locally.
